//UI 상호작용 및 이벤트 처리

// 서브 페이지로 이동하는 함수 추가
function navigateToMovieDetail(movieId) {
  window.location.href = `sub_page/index.html?id=${movieId}`;
}

// 슬라이더 버튼 초기화
function initSlider(sliderElement) {
  const viewport = sliderElement.querySelector('.slider-viewport');
  const slides = sliderElement.querySelector('.hero-slides, .poster-slides');
  const prevBtn = sliderElement.querySelector('.slider-btn.prev');
  const nextBtn = sliderElement.querySelector('.slider-btn.next');
  
  if (!viewport || !slides || !prevBtn || !nextBtn) return;
  
  // 히어로 슬라이더 체크
  const isHeroSlider = slides.classList.contains('hero-slides');
  
  if (isHeroSlider) {
    let currentIndex = 0;
    const totalSlides = slides.children.length;
    
    function updateSlide() {
      const slideWidth = viewport.clientWidth;
      viewport.scrollLeft = currentIndex * slideWidth;
      
      // 미리보기 업데이트 (포스터만)
      const nextIndex = (currentIndex + 1) % totalSlides;
      updatePreview(nextIndex);
    }
    
    prevBtn.addEventListener('click', () => {
      if (currentIndex > 0) {
        currentIndex--;
      } else {
        currentIndex = totalSlides - 1;
      }
      updateSlide();
    });
    
    nextBtn.addEventListener('click', () => {
      currentIndex = (currentIndex + 1) % totalSlides;
      updateSlide();
    });
    
    // 미리보기 클릭 이벤트 추가
    const previewArticle = document.getElementById('previewArticle');
    if (previewArticle) {
      previewArticle.addEventListener('click', () => {
        currentIndex = (currentIndex + 1) % totalSlides;
        updateSlide();
      });
    }
    
    // 히어로 슬라이드 클릭 이벤트 추가 (상세 페이지로 이동)
    slides.addEventListener('click', (e) => {
      const heroSlide = e.target.closest('.hero-slide');
      if (heroSlide) {
        const movieId = heroSlide.dataset.movieId;
        if (movieId) {
          navigateToMovieDetail(movieId);
        }
      }
    });
    
    // 자동 슬라이드 (8초마다)
    let autoSlide = setInterval(() => {
      currentIndex = (currentIndex + 1) % totalSlides;
      updateSlide();
    }, 8000);

    // 마우스 오버시 자동 슬라이드 중지
    sliderElement.addEventListener('mouseenter', () => clearInterval(autoSlide));
    sliderElement.addEventListener('mouseleave', () => {
      autoSlide = setInterval(() => {
        currentIndex = (currentIndex + 1) % totalSlides;
        updateSlide();
      }, 8000);
    });
    
    // 윈도우 리사이즈 시 슬라이드 위치 재조정
    window.addEventListener('resize', updateSlide);
    
    // 초기 미리보기 설정
    setTimeout(() => updateSlide(), 100);
    
  } else {
    const cards = slides.querySelectorAll('.movie-poster-card');
    if (cards.length === 0) return;
    
    const cardWidth = cards[0].offsetWidth + 12; // gap 포함
    const scrollAmount = cardWidth * 5; // 5개씩 스크롤 유지
    
    prevBtn.addEventListener('click', () => {
      viewport.scrollLeft = Math.max(0, viewport.scrollLeft - scrollAmount);
    });
    
    nextBtn.addEventListener('click', () => {
      viewport.scrollLeft = Math.min(
        viewport.scrollWidth - viewport.clientWidth,
        viewport.scrollLeft + scrollAmount
      );
    });
    
    // 포스터 카드 클릭 이벤트 추가 (상세 페이지로 이동)
    slides.addEventListener('click', (e) => {
      const posterCard = e.target.closest('.movie-poster-card');
      if (posterCard) {
        const movieId = posterCard.dataset.movieId;
        if (movieId) {
          navigateToMovieDetail(movieId);
        }
      }
    });
  }
}

// 미리보기 업데이트 함수 수정 (포스터만 표시)
function updatePreview(nextIndex) {
  if (!heroMovies || heroMovies.length === 0) return;
  
  const nextMovie = heroMovies[nextIndex];
  if (!nextMovie) return;
  
  const previewPoster = document.getElementById('previewPoster');
  
  if (!previewPoster) return;
  
  const posterUrl = nextMovie.poster_path 
    ? `${IMAGE_BASE_URL}/w500${nextMovie.poster_path}`
    : 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzAwIiBoZWlnaHQ9IjQ1MCIgdmlld0JveD0iMCAwIDMwMCA0NTAiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CjxyZWN0IHdpZHRoPSIzMDAiIGhlaWdodD0iNDUwIiBmaWxsPSIjMWQxZDFkIi8+Cjx0ZXh0IHg9IjE1MCIgeT0iMjI1IiBmaWxsPSIjYmRiZGJkIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBmb250LXNpemU9IjE2IiBmb250LXdlaWdodD0iYm9sZCI+Tm8gSW1hZ2U8L3RleHQ+Cjwvc3ZnPgo=';
  
  previewPoster.src = posterUrl;
  previewPoster.alt = nextMovie.title;
}

// 검색 기능
function initSearchFunction() {
  document.getElementById('searchForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const query = document.getElementById('searchInput').value.trim();
    if (query) {
      const trendingSlides = document.getElementById('trendingSlides');
      trendingSlides.innerHTML = '<div class="loading">🔍 검색 중...</div>';
      
      const movies = await fetchMovies('/search/movie', { 
        query,
        'region': 'KR'
      });
      
      if (movies.length > 0) {
        const filteredMovies = movies.filter(movie => 
          movie.poster_path && movie.adult === false
        ).slice(0, 10); // 10개 제한
        
        if (filteredMovies.length > 0) {
          trendingSlides.innerHTML = filteredMovies
            .map(movie => createPosterCard(movie))
            .join('');
        } else {
          trendingSlides.innerHTML = '<div class="error">검색 결과가 없습니다 😔</div>';
        }
      } else {
        trendingSlides.innerHTML = '<div class="error">검색 결과가 없습니다 😔</div>';
      }
      
      // 슬라이더 버튼 재초기화
      setTimeout(() => {
        const slider = document.getElementById('trendingSlider');
        initSlider(slider);
      }, 100);
    }
  });
}

// 카테고리 필터 기능
function initCategoryFilter() {
  document.querySelectorAll('.chip').forEach(chip => {
    chip.addEventListener('click', async (e) => {
      e.preventDefault();
      
      // 활성 상태 업데이트
      document.querySelectorAll('.chip').forEach(c => c.classList.remove('active'));
      chip.classList.add('active');
      
      const category = chip.dataset.category;
      
      // 트렌딩 슬라이더 업데이트
      await loadSlider('trendingSlides', category, false);
      
      // 슬라이더 버튼 재초기화
      setTimeout(() => {
        const slider = document.getElementById('trendingSlider');
        initSlider(slider);
      }, 100);
    });
  });
}

// URL에서 검색어 확인하고 처리하는 함수 추가
function handleURLSearch() {
  const urlParams = new URLSearchParams(window.location.search);
  const searchQuery = urlParams.get('search');
  
  if (searchQuery) {
    // 검색어 입력 필드에 설정
    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
      searchInput.value = searchQuery;
      
      // 검색 실행
      const searchForm = document.getElementById('searchForm');
      if (searchForm) {
        searchForm.dispatchEvent(new Event('submit'));
      }
    }
    
    // URL에서 검색 파라미터 제거 (브라우저 히스토리 깔끔하게 유지)
    window.history.replaceState({}, document.title, window.location.pathname);
  }
}

// 초기화 함수
async function init() {
  console.log('🎬 왓챠 클론 초기화 시작...');
  
  try {
    // API 키 테스트
    console.log('API 키 테스트 중...');
    const testMovies = await fetchMovies('/movie/popular');
    if (testMovies.length > 0) {
      console.log('API 키 정상 작동');
    } else {
      console.warn('API 응답이 비어있음');
    }
    
    // 히어로 슬라이더 - 한국 현재 상영작
    console.log('히어로 슬라이더 로드 중...');
    await loadSlider('heroSlides', 'now_playing', true);
    
    // 트렌딩 슬라이더
    console.log('트렌딩 슬라이더 로드 중...');
    await loadSlider('trendingSlides', 'trending', false);
    
    // 한국 영화 슬라이더
    console.log('🇰🇷 한국 영화 슬라이더 로드 중...');
    await loadSlider('koreanSlides', 'korean', false);
    
    // 슬라이더 버튼 초기화 (약간의 지연 후)
    setTimeout(() => {
      document.querySelectorAll('.slider').forEach(initSlider);
      console.log('모든 슬라이더 초기화 완료!');
    }, 1000);
    
    // 검색 기능 초기화
    initSearchFunction();
    
    // 카테고리 필터 초기화
    initCategoryFilter();
    
    // URL 검색어 처리
    handleURLSearch();
    
  } catch (error) {
    console.error('초기화 실패:', error);
  }
}

// DOM 로드 완료 시 실행
document.addEventListener('DOMContentLoaded', init);